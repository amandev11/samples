# THIRAK Visual Portfolio

Static, Vercel-ready photography portfolio.

## Deploy
Upload this folder to a Git repository and import it into Vercel, or run `vercel` from the project directory.

`index.html` contains the complete layout, styling and interactions; the optimized photographs live under `assets/`.
